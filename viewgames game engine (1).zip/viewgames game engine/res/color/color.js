document.getElementById("meuElemento").style.color = "red";
$("#meuElemento").css("color", "red");
document.getElementById("meuElemento").classList.add("vermelho");
