document.addEventListener('DOMContentLoaded', () => {
    const player = document.getElementById('player');
    const item = document.getElementById('item');
    const gameContainer = document.getElementById('game-container');
    let playerPosition = gameContainer.offsetWidth / 2 - player.offsetWidth / 2;
    let itemPositionX = Math.random() * (gameContainer.offsetWidth - item.offsetWidth);
    let itemPositionY = 0;
    const itemFallSpeed = 2;
    const playerSpeed = 10;

    player.style.le