document.getElementById('homeButton').addEventListener('click', function() {
  alert('Home button clicked!');
  // Aqui você pode adicionar código para mudar o conteúdo da página
});

document.getElementById('profileButton').addEventListener('click', function() {
  alert('Profile button clicked!');
  // Aqui você pode adicionar código para mudar o conteúdo da página
});

document.getElementById('settingsButton').addEventListener('click', function() {
  alert('Settings button clicked!');
  // Aqui você pode adicionar código para mudar o conteúdo da página
});
// script.js
const config = {
  type: Phaser.AUTO,
  width: 800,
  height: 600,
  scene: {
    preload: preload,
    create: create,
    update: update
  },
  parent: 'gameContainer'
};

const game = new Phaser.Game(config);

function preload() {
  // Carregar ativos aqui
}

function create() {
  // Configurar jogo aqui
}

function update() {
  // Lógica do jogo aqui
}

document.getElementById('playButton').addEventListener('click', function() {
  game.scene.resume();
});

document.getElementById('pauseButton').addEventListener('click', function() {
  game.scene.pause();
});

document.getElementById('restartButton').addEventListener('click', function() {
  game.scene.restart();
});
document.addEventListener('DOMContentLoaded', () => {
    const gameContainer = document.getElementById('game-container');
    
    class GameObject {
        constructor(width, height, color, x, y) {
            this.element = document.createElement('div');
            this.width = width;
            this.height = height;
            this.color = color;
            this.x = x;
            this.y = y;

            this.element.style.width = `${this.width}px`;
            this.element.style.heigh
